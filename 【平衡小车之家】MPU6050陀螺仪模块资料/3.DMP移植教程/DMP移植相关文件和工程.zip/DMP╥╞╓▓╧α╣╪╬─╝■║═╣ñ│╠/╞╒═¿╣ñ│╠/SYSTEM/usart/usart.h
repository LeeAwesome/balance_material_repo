#ifndef __USART_H
#define __USART_H
#include "sys.h"
#include "stdio.h"	 
void uart_init(u32 pclk2,u32 bound);
#endif	   
















